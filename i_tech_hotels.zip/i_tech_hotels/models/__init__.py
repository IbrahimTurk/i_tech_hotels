from . import hotels
from . import account_move
from . import account_payment
from . import res_partner
from . import account_journal

